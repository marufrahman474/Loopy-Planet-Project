﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ConsoleApplication2Loopytest
{
    class Program
    {
        static void Main(string[] args)
        {
            double weight; //The user's weight they input in the textbox
            double menu_num;
            string messageText; //  We've split up the result into two parts, this first one would show a text box stating what your weight would be
            string messageText2; // Now this is the second part of the result, which states the unit  

            bool exit_cond;       //On correct input, this exits prompt loops 
            bool bigexit_cond;    // When the game loop has ended, this line is used to determine when to exit the program


            //this code below, shows the menu to be displayed when the program is started. 
            {
                Console.WriteLine("PLANETS");
                Console.WriteLine();
                Console.WriteLine("1. Jupiter");
                Console.WriteLine("2. Mars");
                Console.WriteLine("3. Mercury");
                Console.WriteLine("4. Neptune");
                Console.WriteLine("5. Pluto");
                Console.WriteLine("6. Saturn");
                Console.WriteLine("7. URANUS");
                Console.WriteLine("8. Venus");
                Console.WriteLine("9. Exit");
                var result = Console.ReadLine();
                
            }



            Console.WriteLine("Enter your menu choice:");
            double[] planetnumber = new double[9] { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            else if (menu_num < 1 | menu_num > 9) throw new ArgumentOutOfRangeException { };  //if the inputted variable falls outside of the range of 1 - 9 the program will show an exception. 

            else if (menu_num == 9)                                   //However with a else if function, if the User exits the program by choosing option 9, the program will initate exit procedures. 
            {
                Console.WriteLine("\nSEE YA FRIENDO!");
                exit_cond = true;
                bigexit_cond = true;
            }


              

            Console.Write("Enter your weight on Earth:");
            weight = int.Parse(Console.ReadLine());



            Console.WriteLine("On the chosen planet, this would be your weight");
            double[] weight = new double[8] { 2.64, 0.38, 0.37, 1.12, 0.04, 1.15, 1.15, 0.88 };
            // In here, the weight variables for the 8 different planets are assigned in the same order as the menu choice. When a user chooses a planet, the program will then use the weight variable assigned to that planet. 


            Console.WriteLine(weight[2] * 130); // in here, we have put in a weight of 130 pounds, however in an ideal situation instead of putting the weight value in the code, it would be much better to have the user input their weight themselves on CMD or Form. 
      

      

        }
    }
}
